<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "training";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Ошибка подключения: " . $conn->connect_error);
}
// обработка данных из формы добавления задания
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $title = $_POST["title"];
  $deadline = $_POST["deadline"];
  $description = $_POST["description"];
  // Вставка данных в таблицу заданий
  $query = "INSERT INTO assignment (title, deadline, description) VALUES ('$title', '$deadline', '$description')";
  if ($conn->query($query) === TRUE) {
   echo "Задание успешно добавлено";
    // header("Location: http://localhost/Student_Dash.php");
  } else {
    echo
      "Ошибка добавления задания: " . $conn->error;
  }
}
$conn->close();
?>