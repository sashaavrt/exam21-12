<?php
session_start();
include("./includes/connect.php");
?> 
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="./style/style.css">
        <title>Добавить новость</title>
    </head>
    <body>
        <h2>Добавить новость</h2>
        <form action="./functions/process_add_news.php" method="post">
        <label for="title">Заголовок: </label>
        <textarea type="text" id="title" name="title" required></textarea><br>

        <label for="content">Содержание: </label>
        <textarea id="content" name="content" required></textarea><br>

        <input type="submit" value="">
        </form>
    </body>
    </html>


