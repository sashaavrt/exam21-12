<?php
session_start();
include("./functions/process_add_assignments.php");
?> 

<!DOCTYPE html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1…0">
  <link rel="stylesheet" href="./style/style.css">
  <title>Добавление заданий</title>
</head>

<body>
  <div class="container">
    <h2>Добавление заданий</h2>
    <form action="add_assignment.php" method="post">
      <label for="title">Название:</label>
      <input type="text" id="title" name="title" required>

      <label for="deadline">Дедлайн: </label>
      <input type="date" id="deadline" name="deadline" required>

      <label for="description">Описание задания: </label>
      <textarea id="description" name="description" rows="4" required></textarea>

      <button type="submit">добавить задание</button>
    </form>
  </div>
</body>

</html>